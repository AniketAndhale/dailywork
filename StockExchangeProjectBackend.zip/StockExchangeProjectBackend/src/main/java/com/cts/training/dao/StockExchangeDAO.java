//package com.cts.training.dao;
//
//import java.util.List;
//
//import com.cts.training.bean.StockExchange;
//
//public interface StockExchangeDAO {
//	
//	public boolean saveStockExchange(StockExchange stockExchange);
//	
//	public boolean updateStockExchange(StockExchange stockExchange);
//	
//	public boolean removeStockExchange(StockExchange stockExchange);
//	
//	public StockExchange getStockExchangeById(int id);
//	
//	public List<StockExchange> displayAllStockExchanges();
//
//}
